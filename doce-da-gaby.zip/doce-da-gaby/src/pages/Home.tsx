import { useEffect, useRef } from "react";

const WHATSAPP_URL = "https://wa.me/5516994277738";
const WHATSAPP_NUMBER = "(16) 99427-7738";

const products = [
  {
    name: "Brigadeiro Gourmet",
    price: "R$ 4,50",
    emoji: "🍫",
    description: "Cremoso, com granulado belga e recheios especiais que derretem na boca.",
    color: "from-amber-100 to-amber-50",
  },
  {
    name: "Bolo no Pote",
    price: "R$ 18,00",
    emoji: "🎂",
    description: "Camadas generosas de bolo fofinho com recheio e cobertura artesanal.",
    color: "from-pink-100 to-pink-50",
  },
  {
    name: "Cheesecake",
    price: "R$ 22,00",
    emoji: "🍰",
    description: "Cremoso, com calda de frutas frescas e base crocante de biscoito.",
    color: "from-yellow-100 to-yellow-50",
  },
  {
    name: "Torta de Limão",
    price: "R$ 20,00",
    emoji: "🍋",
    description: "Recheio azedinho e suave no merengue italiano irresistível.",
    color: "from-lime-100 to-lime-50",
  },
  {
    name: "Pudim Caseiro",
    price: "R$ 15,00",
    emoji: "🍮",
    description: "Feito no capricho, com leite condensado e calda de caramelo.",
    color: "from-orange-100 to-orange-50",
  },
  {
    name: "Caixa de Doces",
    price: "R$ 45,00",
    emoji: "🎁",
    description: "Caixa especial com mix dos nossos melhores doces artesanais.",
    color: "from-rose-100 to-rose-50",
  },
];

const testimonials = [
  {
    name: "Ana Paula",
    text: "Os brigadeiros da Gaby são os melhores que já comi! Peço toda semana. Qualidade incrível!",
    stars: 5,
    initial: "A",
  },
  {
    name: "Carlos M.",
    text: "Encomendei para o aniversário da minha filha e todos amaram. Entrega super pontual!",
    stars: 5,
    initial: "C",
  },
  {
    name: "Fernanda Lima",
    text: "Deliciosos! O bolo no pote é uma obra de arte. Recomendo de olhos fechados!",
    stars: 5,
    initial: "F",
  },
  {
    name: "João R.",
    text: "Atendimento ótimo e os doces são maravilhosos. Vira cliente fiel na hora!",
    stars: 5,
    initial: "J",
  },
];

export default function Home() {
  const sectionsRef = useRef<NodeListOf<Element> | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.15 }
    );

    const sections = document.querySelectorAll(".section-reveal");
    sectionsRef.current = sections;
    sections.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* FLOATING WHATSAPP BUTTON */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float"
        aria-label="WhatsApp"
      >
        <div className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-full shadow-2xl transition-colors duration-200">
          <svg viewBox="0 0 32 32" className="w-6 h-6 fill-current flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
            <path d="M16 0C7.163 0 0 7.163 0 16c0 2.827.738 5.476 2.027 7.781L0 32l8.467-2.004A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.333a13.28 13.28 0 01-6.773-1.853l-.486-.289-5.027 1.19 1.214-4.894-.318-.502A13.28 13.28 0 012.667 16C2.667 8.636 8.636 2.667 16 2.667S29.333 8.636 29.333 16 23.364 29.333 16 29.333zm7.307-9.92c-.4-.2-2.363-1.165-2.729-1.298-.366-.133-.633-.2-.9.2-.267.4-1.032 1.298-1.265 1.565-.233.267-.466.3-.866.1-.4-.2-1.689-.623-3.218-1.985-1.19-1.06-1.993-2.37-2.226-2.77-.233-.4-.025-.617.175-.817.18-.18.4-.467.6-.7.2-.233.267-.4.4-.667.133-.267.067-.5-.033-.7-.1-.2-.9-2.17-1.233-2.97-.325-.78-.655-.674-.9-.686l-.766-.013c-.267 0-.7.1-1.066.5-.367.4-1.4 1.365-1.4 3.33s1.433 3.863 1.633 4.13c.2.267 2.82 4.3 6.827 6.033.954.413 1.698.66 2.279.845.958.305 1.83.262 2.52.159.768-.115 2.363-.965 2.696-1.897.333-.933.333-1.733.233-1.9-.1-.167-.367-.267-.767-.467z"/>
          </svg>
          <span className="font-semibold text-sm hidden sm:inline">Fazer Pedido</span>
        </div>
      </a>

      {/* HERO SECTION */}
      <section className="hero-section relative min-h-screen flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/45 to-black/70" />
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="animate-fade-in-up" style={{ animationDelay: "0.1s", opacity: 0 }}>
            <span className="inline-block text-rose-300 text-sm font-semibold tracking-widest uppercase mb-4 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full border border-rose-300/30">
              ✨ Artesanal com amor
            </span>
          </div>
          <h1
            className="text-5xl sm:text-6xl md:text-7xl font-bold text-white mb-4 leading-tight animate-fade-in-up"
            style={{ animationDelay: "0.2s", opacity: 0, fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Doce da Gaby
          </h1>
          <p
            className="text-2xl sm:text-3xl text-rose-200 font-medium mb-6 animate-fade-in-up"
            style={{ animationDelay: "0.35s", opacity: 0 }}
          >
            Os doces mais irresistíveis de Matão 🍰✨
          </p>
          <p
            className="text-white/80 text-lg mb-10 max-w-xl mx-auto animate-fade-in-up"
            style={{ animationDelay: "0.5s", opacity: 0 }}
          >
            Brigadeiros, bolos, sobremesas e muito mais — feitos com ingredientes selecionados e aquele toque caseiro que conquista qualquer um.
          </p>
          <div className="animate-fade-in-up" style={{ animationDelay: "0.65s", opacity: 0 }}>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-green-500 hover:bg-green-600 active:bg-green-700 text-white font-bold text-lg px-10 py-5 rounded-full shadow-2xl transition-all duration-200 hover:scale-105 active:scale-95"
            >
              <svg viewBox="0 0 32 32" className="w-6 h-6 fill-current flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 0C7.163 0 0 7.163 0 16c0 2.827.738 5.476 2.027 7.781L0 32l8.467-2.004A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.333a13.28 13.28 0 01-6.773-1.853l-.486-.289-5.027 1.19 1.214-4.894-.318-.502A13.28 13.28 0 012.667 16C2.667 8.636 8.636 2.667 16 2.667S29.333 8.636 29.333 16 23.364 29.333 16 29.333zm7.307-9.92c-.4-.2-2.363-1.165-2.729-1.298-.366-.133-.633-.2-.9.2-.267.4-1.032 1.298-1.265 1.565-.233.267-.466.3-.866.1-.4-.2-1.689-.623-3.218-1.985-1.19-1.06-1.993-2.37-2.226-2.77-.233-.4-.025-.617.175-.817.18-.18.4-.467.6-.7.2-.233.267-.4.4-.667.133-.267.067-.5-.033-.7-.1-.2-.9-2.17-1.233-2.97-.325-.78-.655-.674-.9-.686l-.766-.013c-.267 0-.7.1-1.066.5-.367.4-1.4 1.365-1.4 3.33s1.433 3.863 1.633 4.13c.2.267 2.82 4.3 6.827 6.033.954.413 1.698.66 2.279.845.958.305 1.83.262 2.52.159.768-.115 2.363-.965 2.696-1.897.333-.933.333-1.733.233-1.9-.1-.167-.367-.267-.767-.467z"/>
              </svg>
              Fazer Pedido no WhatsApp
            </a>
          </div>
          <div
            className="mt-16 animate-fade-in-up"
            style={{ animationDelay: "0.8s", opacity: 0 }}
          >
            <a href="#sobre" className="text-white/60 hover:text-white transition-colors">
              <div className="flex flex-col items-center gap-2">
                <span className="text-sm tracking-wider">Descubra mais</span>
                <svg className="w-5 h-5 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* SOBRE SECTION */}
      <section id="sobre" className="py-20 px-4" style={{ background: "linear-gradient(135deg, #fff5f7 0%, #fdf0e8 50%, #fff5f7 100%)" }}>
        <div className="max-w-4xl mx-auto text-center section-reveal">
          <div className="text-5xl mb-6">🎀</div>
          <h2 className="text-4xl font-bold mb-6" style={{ color: "#b5366a", fontFamily: "'Playfair Display', Georgia, serif" }}>
            Nossa História
          </h2>
          <p className="text-xl text-stone-600 leading-relaxed max-w-2xl mx-auto mb-8">
            "Feitos com amor, ingredientes selecionados e aquele toque caseiro que conquista qualquer um."
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-10">
            {[
              { icon: "💝", title: "Feito com Amor", desc: "Cada doce é preparado com carinho e dedicação" },
              { icon: "🌿", title: "Ingredientes Frescos", desc: "Selecionamos apenas o melhor para você" },
              { icon: "🏡", title: "Toque Caseiro", desc: "Receitas artesanais que remetem ao aconchego de casa" },
            ].map((item) => (
              <div key={item.title} className="bg-white rounded-2xl p-6 shadow-sm border border-rose-100">
                <div className="text-4xl mb-3">{item.icon}</div>
                <h3 className="font-bold text-rose-700 text-lg mb-2">{item.title}</h3>
                <p className="text-stone-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUTOS SECTION */}
      <section id="produtos" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center section-reveal mb-14">
            <div className="text-5xl mb-4">🍬</div>
            <h2 className="text-4xl font-bold mb-4" style={{ color: "#b5366a", fontFamily: "'Playfair Display', Georgia, serif" }}>
              Nossos Doces
            </h2>
            <p className="text-stone-500 text-lg max-w-xl mx-auto">
              Uma seleção irresistível de doces artesanais para adoçar o seu dia
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, i) => (
              <a
                key={product.name}
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className={`product-card section-reveal rounded-2xl overflow-hidden shadow-md border border-rose-100 block bg-gradient-to-br ${product.color} cursor-pointer`}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className="p-8">
                  <div className="text-6xl mb-4 text-center">{product.emoji}</div>
                  <h3 className="font-bold text-xl text-stone-800 mb-2 text-center">{product.name}</h3>
                  <p className="text-stone-500 text-sm text-center mb-4 leading-relaxed">{product.description}</p>
                  <div className="text-center">
                    <span className="inline-block bg-rose-600 text-white font-bold text-lg px-5 py-2 rounded-full">
                      {product.price}
                    </span>
                  </div>
                </div>
                <div className="bg-rose-600 hover:bg-rose-700 text-white text-center py-3 font-semibold text-sm transition-colors">
                  Pedir no WhatsApp →
                </div>
              </a>
            ))}
          </div>
          <div className="text-center mt-12 section-reveal">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-lg px-10 py-4 rounded-full shadow-lg transition-all duration-200 hover:scale-105 active:scale-95"
            >
              Ver Cardápio Completo no WhatsApp
            </a>
          </div>
        </div>
      </section>

      {/* DEPOIMENTOS SECTION */}
      <section id="depoimentos" className="py-20 px-4" style={{ background: "linear-gradient(135deg, #fce4ec 0%, #fdf0e8 100%)" }}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center section-reveal mb-14">
            <div className="text-5xl mb-4">⭐</div>
            <h2 className="text-4xl font-bold mb-4" style={{ color: "#b5366a", fontFamily: "'Playfair Display', Georgia, serif" }}>
              O que nossos clientes dizem
            </h2>
            <p className="text-stone-500 text-lg">Experiências reais de quem já experimentou</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={t.name}
                className="section-reveal bg-white rounded-2xl p-7 shadow-sm border border-rose-100"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: t.stars }).map((_, si) => (
                    <svg key={si} className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-stone-600 italic mb-5 leading-relaxed">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, #e91e8c, #c2185b)" }}
                  >
                    {t.initial}
                  </div>
                  <span className="font-semibold text-stone-700">{t.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTATO SECTION */}
      <section id="contato" className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center section-reveal mb-12">
            <div className="text-5xl mb-4">📍</div>
            <h2 className="text-4xl font-bold mb-4" style={{ color: "#b5366a", fontFamily: "'Playfair Display', Georgia, serif" }}>
              Onde Estamos
            </h2>
            <p className="text-stone-500 text-lg">Venha nos visitar ou faça seu pedido pelo WhatsApp</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="section-reveal space-y-6">
              <div className="bg-rose-50 border border-rose-100 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="text-3xl">📌</div>
                  <div>
                    <h3 className="font-bold text-rose-700 text-lg mb-2">Endereço</h3>
                    <p className="text-stone-600 leading-relaxed">
                      Av. Francisco Mastropietro, 2107<br />
                      Jardim Primavera, Matão - SP<br />
                      CEP: 15997-300
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-green-50 border border-green-100 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="text-3xl">📱</div>
                  <div>
                    <h3 className="font-bold text-green-700 text-lg mb-2">Telefone / WhatsApp</h3>
                    <a
                      href={WHATSAPP_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-green-600 hover:text-green-700 font-semibold text-lg transition-colors"
                    >
                      {WHATSAPP_NUMBER}
                    </a>
                  </div>
                </div>
              </div>
              <div className="bg-amber-50 border border-amber-100 rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="text-3xl">🕐</div>
                  <div>
                    <h3 className="font-bold text-amber-700 text-lg mb-2">Atendimento</h3>
                    <p className="text-stone-600">Seg – Sex: 8h às 19h</p>
                    <p className="text-stone-600">Sáb: 8h às 17h</p>
                    <p className="text-stone-500 text-sm mt-1">Encomendas com antecedência</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="section-reveal flex flex-col gap-4">
              <div
                className="flex-1 rounded-2xl flex items-center justify-center p-10 text-center"
                style={{ background: "linear-gradient(135deg, #fce4ec 0%, #fdf0e8 100%)" }}
              >
                <div>
                  <div className="text-7xl mb-6">🍰</div>
                  <p className="text-stone-600 text-lg leading-relaxed mb-6">
                    Faça seu pedido agora e receba doces fresquinhos feitos com todo o carinho da Gaby!
                  </p>
                  <a
                    href={WHATSAPP_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 bg-green-500 hover:bg-green-600 text-white font-bold text-lg px-8 py-4 rounded-full shadow-lg transition-all duration-200 hover:scale-105 active:scale-95"
                  >
                    <svg viewBox="0 0 32 32" className="w-6 h-6 fill-current flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
                      <path d="M16 0C7.163 0 0 7.163 0 16c0 2.827.738 5.476 2.027 7.781L0 32l8.467-2.004A15.94 15.94 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.333a13.28 13.28 0 01-6.773-1.853l-.486-.289-5.027 1.19 1.214-4.894-.318-.502A13.28 13.28 0 012.667 16C2.667 8.636 8.636 2.667 16 2.667S29.333 8.636 29.333 16 23.364 29.333 16 29.333zm7.307-9.92c-.4-.2-2.363-1.165-2.729-1.298-.366-.133-.633-.2-.9.2-.267.4-1.032 1.298-1.265 1.565-.233.267-.466.3-.866.1-.4-.2-1.689-.623-3.218-1.985-1.19-1.06-1.993-2.37-2.226-2.77-.233-.4-.025-.617.175-.817.18-.18.4-.467.6-.7.2-.233.267-.4.4-.667.133-.267.067-.5-.033-.7-.1-.2-.9-2.17-1.233-2.97-.325-.78-.655-.674-.9-.686l-.766-.013c-.267 0-.7.1-1.066.5-.367.4-1.4 1.365-1.4 3.33s1.433 3.863 1.633 4.13c.2.267 2.82 4.3 6.827 6.033.954.413 1.698.66 2.279.845.958.305 1.83.262 2.52.159.768-.115 2.363-.965 2.696-1.897.333-.933.333-1.733.233-1.9-.1-.167-.367-.267-.767-.467z"/>
                    </svg>
                    Chamar no WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: "linear-gradient(135deg, #6b1e3d 0%, #8b2252 100%)" }} className="text-white py-12 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              Doce da Gaby
            </h3>
            <p className="text-rose-200 text-sm">Feitos com amor, ingredientes selecionados e toque caseiro</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mb-8 text-center sm:text-left">
            <div>
              <h4 className="font-semibold text-rose-200 uppercase text-xs tracking-wider mb-3">Endereço</h4>
              <p className="text-white/80 text-sm leading-relaxed">
                Av. Francisco Mastropietro, 2107<br />
                Jardim Primavera, Matão - SP<br />
                CEP: 15997-300
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-rose-200 uppercase text-xs tracking-wider mb-3">Contato</h4>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/80 hover:text-white transition-colors text-sm block"
              >
                📱 {WHATSAPP_NUMBER}
              </a>
            </div>
            <div>
              <h4 className="font-semibold text-rose-200 uppercase text-xs tracking-wider mb-3">Pedidos</h4>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-semibold text-sm px-5 py-2.5 rounded-full transition-all duration-200 hover:scale-105"
              >
                WhatsApp
              </a>
            </div>
          </div>
          <div className="border-t border-white/10 pt-6 text-center">
            <p className="text-white/50 text-xs">
              © 2025 Doce da Gaby. Todos os direitos reservados. 🍫
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
